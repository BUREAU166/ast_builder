#include "adder.h"

int Adder::increment() {
  val++;
  return val;
}

int Adder::decrement() {
  val--;
  return val;
}
